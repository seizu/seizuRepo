# plugin.video.filmpalast.ex
Kodi Video Plugin for Filmpalast.to

**New version with byPass DNS-Lock option**

Installation
------------
Step by step instructions can be found here: https://seizu.github.io/seizuRepo/

List View
<img src="./screenshot.png"/> 

Settings - View
<img src="./screenshot_settings.png"/>
