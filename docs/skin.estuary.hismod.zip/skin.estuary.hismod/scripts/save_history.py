import xbmcgui
import xbmcvfs
import json

try:
    # get keyboard window
    win = xbmcgui.Window(10103)
    # read control 312 (textbox)
    edit_control = win.getControl(312)
    input_text = edit_control.getText()
    

    if input_text and input_text.strip():

        temp_dir = xbmcvfs.translatePath("special://temp")
        history_file = temp_dir + "keyboard_history.json"
        
        # load history
        history = []
        if xbmcvfs.exists(history_file):
            with open(history_file, 'r', encoding='utf-8') as f:
                history = json.load(f)
        
        # remove dups
        history = [item for item in history if item != input_text]
        
        #add text
        history.insert(0, input_text)
        
        # max. entries 50
        history = history[:50]
        
        # save
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
            
except Exception as e:
    pass