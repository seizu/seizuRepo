import xbmcgui
import xbmcvfs
import xbmc
import json

title = "History"

try:

    win = xbmcgui.Window(10103)
    # read control 312 (textbox)
    edit_control = win.getControl(312)
    edit_control.setText("")

    temp_dir = xbmcvfs.translatePath("special://temp")
    history_file = temp_dir + "keyboard_history.json"
    
    # load history
    history = []
    if xbmcvfs.exists(history_file):
        with open(history_file, 'r', encoding='utf-8') as f:
            history = json.load(f)
    
    if not history:
        dialog = xbmcgui.Dialog()
        dialog.notification(title, 'No entries', xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        # add clear button
        display_list = [f"[Clear {title}]"] + history
        
        dialog = xbmcgui.Dialog()
        selected = dialog.select(title, display_list)
        
        if selected == 0:
            xbmcvfs.delete(history_file)            
        elif selected > 0:
            chosen_text = history[selected - 1]    
            request = {
                "jsonrpc": "2.0",
                "method": "Input.SendText",
                "params": {"text": chosen_text, "done": False},
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(request))
            
except Exception as e:
    dialog = xbmcgui.Dialog()
    dialog.notification('Error', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)